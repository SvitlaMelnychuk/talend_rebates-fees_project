print('Hello world.')
