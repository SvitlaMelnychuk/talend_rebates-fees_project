print('Not today.')


