print('Farewell.')
